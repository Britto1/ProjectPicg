#include "Cor.h"

Cor::Cor()
{
    //ctor
}

Cor::~Cor()
{
    //dtor
}
