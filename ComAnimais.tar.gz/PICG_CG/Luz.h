#ifndef LUZ_H
#define LUZ_H

#include <vector>

using namespace std;

class Luz {
public:
    Luz(int altura, vector<vector<char>> &mundo);

    void iluminar(int autura, vector<vector<char>> &mundo);

    void desenharLuz(int altura);

    void propriedade();
};


#endif //LUZ_H
