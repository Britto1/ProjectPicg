#ifndef COR_H
#define COR_H

#include <vector>

class Cor
{
    public:
        Cor();
        virtual ~Cor();
};

#endif // COR_H
