#include "Arquivo.h"
#include <sstream>

using namespace std;


Arquivo::Arquivo() {

}

void Arquivo::CarregarArquivo(string nomeArquivo) {

    ifstream entrada;
    int aux=0;
    string texto;
    entrada.open(nomeArquivo);
    	while(!entrada.eof()){
		entrada >> texto;
			if(aux>0 && aux<4){
				this->cena.push_back(stoi(texto));
			}else if(aux>4 && aux<6){
				this->ilha=stoi(texto);
			}else if(aux>6 && aux<8){
				this->lagos=stoi(texto);
			}else if(aux>8 && aux<10){
				this->terrestres_1=stoi(texto);
			}else if(aux>10 && aux<12){
				this->terrestres_2=stoi(texto);
			}else if(aux>12 && aux<14){
				this->aereos_1=stoi(texto);
			}else if(aux>14 && aux<16){
				this->aereos_2=stoi(texto);
			}else if(aux>16 && aux<18){
				this->plantas_1=stoi(texto);
			}else if(aux>18 && aux<20){
				this->plantas_2=stoi(texto);
			}

		aux++;
		}
}

const vector<int> &Arquivo::getCena() const {
    return cena;
}

const int Arquivo::getIlha() const {
    return ilha;
}

const int Arquivo::getLagos() const {
    return lagos;
}

const int Arquivo::getTerrestres_1() const {
    return terrestres_1;
}

const int Arquivo::getTerrestres_2() const {
    return terrestres_2;
}

const int Arquivo::getAereos_1() const {
    return aereos_1;
}

const int Arquivo::getAereos_2() const {
    return aereos_2;
}

const int Arquivo::getPlantas_1() const {
    return plantas_1;
}

const int Arquivo::getPlantas_2() const {
    return plantas_2;
}
