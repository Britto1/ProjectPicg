#include "Cam.h"
#include <GL/gl.h>
#include <iostream>
#include <vector>
#include <cmath>


Cam::Cam(vector<vector<char>> mundo){
   this->posicaox = 40.0;
   this->posicaoy = 80;
   this->posicaoz = 30.0;
   this->rotacaox = 0.0;
   this->rotacaoy = -0.2;
   this->rotacaoz = 0.1;
   this->cameraVelocidade = 0.15;
}

float Cam::getPosicaox() const{
    return this->posicaox;
}

void Cam::setPosicaox(float posx){
    this->posicaox = posx;
}

float Cam::getPosicaoy() const{
    return this->posicaoy;
}

void Cam::setPosicaoy(float posy){
    this->posicaoy = posy;
}

void Cam::setPosicaoz(float posz){
    this->posicaoz = posz;
}

float Cam::getPosicaoz() const{
    return this->posicaoz;
}

float Cam::getRotacaox() const{
    return this->rotacaox;
}

void Cam::setRotacaox(float rotx){
    this->rotacaox = rotx;
}

float Cam::getRotacaoy() const{
    return this->rotacaoy;
}

void Cam::setRotacaoy(float roty){
    this->rotacaoy = roty;
}

float Cam::getRotacaoz() const{
    return this->rotacaoz;
}

void Cam::setRotacaoz(float rotz){
    this->rotacaoz = rotz;
}

float Cam::getCameraVelocidade() const{
    return this->cameraVelocidade;
}

void Cam::setCameraVelocidade(float cameraVelocidade){
    this->cameraVelocidade = cameraVelocidade;
}


Cam::~Cam()
{
    //dtor
}

