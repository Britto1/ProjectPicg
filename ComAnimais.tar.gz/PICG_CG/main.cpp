//Classes:
#include "Ambiente.h"
#include "Cam.h"
#include "Luz.h"
#include "Arquivo.h"
#include "Animal.h"
//bibliotecas do C++:
#include <vector>
#include <string>
#include <cstdlib>
#include <GL/freeglut.h>
#include <GL/glu.h>
#include <math.h>
#include <GL/gl.h>
#include <GL/glut.h>
#include <iostream>
static GLfloat spin = 0.0;
using namespace std;

Ambiente *ambiente;
vector<vector<char>> mundo;
Luz* luz;
Arquivo arquivo;

Cam *camera;
int posicaoMouseX;
int posicaoMouseY;
vector<Animal> zebras;
vector<Animal> leoes;


void criarAnimais(int nAnimais, short tipo, int taxaDiminuicao) {
    int x, z;
    for (int i = 0; i < nAnimais; i++) {
        srand((unsigned int) time(NULL));

        Animal a = *new Animal(tipo, taxaDiminuicao);

        do {
            x = (int) (rand() % (mundo[0].size() - 1));
            z = (int) (rand() % (mundo.size() - 1));

            a.setSentidoX(x);
            a.setSentidoZ(z);

        } while (!a.gerar(mundo));

        if (tipo == 1) {
            leoes.push_back(a);
        } else {
            zebras.push_back(a);
        }

    }

}
//vector<Animal> lobo;
/*

void criarAnimais(int nAnimais, short tipo) {
    int x, z;
    for (int i = 0; i < nAnimais; i++) {
        srand((unsigned int) time(NULL));

        Animal a = *new Animal(tipo);

        do {
            x = (int) (rand() % (mundo[0].size() - 1));
            z = (int) (rand() % (mundo.size() - 1));

            a.setSentidoX(x);
            a.setSentidoZ(z);

        } while (!a.gerar(mundo));

        lobo.push_back(a);

    }

}
*/

void init(){
    arquivo = *new Arquivo();

    arquivo.CarregarArquivo("entrada.txt");
/*
cena 8 12 10
ilha 80
lagos 20
terrestres_1 2
terrestres_2 3
aereos_1 4
aereos_2 5
plantas_1 6
plantas_2 7
*/

    int codX = (arquivo.getCena()[0]) * 10;
    int codZ = (arquivo.getCena()[2]) * 10;
    float sizeIlha = arquivo.getIlha();
    int sizeLagos = arquivo.getLagos();
    int nTerrestres_1 = arquivo.getTerrestres_1();
    int nTerrestres_2 = arquivo.getTerrestres_2();
    int nAereos_1 = arquivo.getAereos_1();
    int nAereos_2 = arquivo.getAereos_2();
    int nPlantas_1 = arquivo.getPlantas_1();
    int nPlantas_2 = arquivo.getPlantas_2();

    mundo.resize((int )codZ);
    for(int i=0;i< (int) mundo.size();i++){
        mundo[i].resize((int)codX);
    }
    glClearColor(0.0, 0.10, 0.20, 1.0);//Define a cor do fundo (atual: azul escuro)
    glPolygonMode(GL_BACK, GL_LINE);
    glShadeModel(GL_SMOOTH);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluPerspective(90, (GLfloat) codX / (GLfloat) codZ, 0.1f, 1000);

    camera = new Cam(mundo); //instancia da camera
    luz = new Luz(30, mundo); //instancia da lua
    ambiente = new  Ambiente(sizeIlha); //instancia do ambiente
    ambiente->criarOceano(mundo); //definicao do oceano na matriz
    ambiente->criarIlha(mundo); // definicao da ilha na matriz

    //criarAnimais(nTerrestres_1,1);
    criarAnimais(5, 0, 0);//Criando zebra
    criarAnimais(3, 1, 0);//Criando leão


    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();

}

void movimentarMouse(int x, int y){
//    cout << "rot x e y antes: " << camera->getRotacaox() << " " << camera->getRotacaoy() <<endl;
    camera->setRotacaoy(camera->getRotacaoy()- 0.002*(x-posicaoMouseX) );
    camera->setRotacaox(camera->getRotacaox()- 0.002*(y-posicaoMouseY) );
    glutPostRedisplay();
    posicaoMouseY = y;
    posicaoMouseX = x;
}

void atualizarMouse(int x, int y){
    posicaoMouseY = y;
    posicaoMouseX = x;

}



void specialKeys(int key, int x, int y){
//   cout << "rot x y z: (" << camera->getRotacaox() << ", " << camera->getRotacaoy() << ", " << camera->getRotacaoz() << endl;
    switch (key) {

        case GLUT_KEY_UP:
            if(camera->getRotacaox() > 0.8)
                camera->setPosicaox(camera->getPosicaox() + 0.9);
            else if( camera->getRotacaox() < -0.8 )
                camera->setPosicaox(camera->getPosicaox() - 0.9);
			camera->setPosicaoy(camera->getPosicaoy() - 0.6);
			break;

        case GLUT_KEY_DOWN:
           // if()
            if(camera->getRotacaox() > 0.8)
                camera->setPosicaox(camera->getPosicaox() - 0.9);
            else if( camera->getRotacaox() < -0.8 )
                camera->setPosicaox(camera->getPosicaox() + 0.9);
			camera->setPosicaoy(camera->getPosicaoy() + 0.6);
			break;

        case GLUT_KEY_LEFT :   //teste
            camera->setPosicaoy(camera->getPosicaoy() + camera->getCameraVelocidade()*cos(camera->getRotacaoy()*M_PI/180 + M_PI/2)*cos(camera->getRotacaox()*M_PI/180) );
            camera->setPosicaoz(camera->getPosicaoz() + camera->getCameraVelocidade()*sin(camera->getRotacaox()*M_PI/180) );
            camera->setPosicaox(camera->getPosicaox() + camera->getCameraVelocidade()*cos(camera->getRotacaox()*M_PI/180)*sin(camera->getRotacaoy()*M_PI/180 + M_PI/2) );
            break;

        case GLUT_KEY_RIGHT :   //teste2
            camera->setPosicaoy(camera->getPosicaoy() - camera->getCameraVelocidade()*cos(camera->getRotacaoy()*M_PI/180 + M_PI/2)*cos(camera->getRotacaox()*M_PI/180) );
            camera->setPosicaoz(camera->getPosicaoz() - camera->getCameraVelocidade()*sin(camera->getRotacaox()*M_PI/180) );
            camera->setPosicaox(camera->getPosicaox() - camera->getCameraVelocidade()*cos(camera->getRotacaox()*M_PI/180)*sin(camera->getRotacaoy()*M_PI/180 + M_PI/2) );
            break;
    }
 //   glLoadIdentity();
    gluLookAt(camera->getPosicaox(),camera->getPosicaoy(),camera->getPosicaoz(), 0,0,0, 0,1,0);
    glutPostRedisplay();
//    glPopMatrix();
}


void display(){
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    gluLookAt(
            camera->getPosicaox(),
            camera->getPosicaoy(),
            camera->getPosicaoz(),
            camera->getPosicaox() + camera->getRotacaox(),
            camera->getPosicaoy() + camera->getRotacaoy(),
            camera->getPosicaoz() + camera->getRotacaoz(),
            0.0,
            1.0,
            0.0);

    luz->propriedade();

    glPushMatrix();

    glPushAttrib(GL_CURRENT_BIT);
   // glPushMatrix();
    luz->desenharLuz(30);
    ambiente->desenharAmbiente(mundo);

    for (auto &&z : zebras) {
        z.movimentar(mundo);

    }

    for (int i = 0; i < leoes.size(); i++) {

        leoes[i].movimentar(mundo);//movimenta cada leão

    }
    // for (int i = 0; i < lobo.size(); i++) {

    //    lobo[i].movimentar(mundo);//movimenta cada leão
   //  }

    glPopAttrib();
    glPopMatrix();
    glutSwapBuffers();

}

void spinDisplay(void) {
    spin = (GLfloat) (spin + 2.0);
    if (spin > 360.0)
        spin = (GLfloat) (spin - 360.0);

    glutPostRedisplay();
}

//função chamada quando a tela é redimensionada
void reshape(int w, int h) {
    glViewport(0, 0, (GLsizei) w, (GLsizei) h);
   //adicionado por mim
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();

   gluPerspective(60.0,((double)w)/h,0.5, 1000.0);

   glMatrixMode(GL_MODELVIEW);
   glLoadIdentity();
   //até aqui

}



int main(int argc, char** argv){
    glutInit(&argc,argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
    glutInitWindowSize(500,500);
    glutInitWindowPosition(500,500);
    glutCreateWindow("Ilha");

    init();
    glutDisplayFunc(display);
//here i modify
//    glutKeyboardFunc(specialKeys);
 //   glutSpecialFunc(specialKeys);
    glutReshapeFunc(reshape);
	// Especifica posição do observador e do alvo

glutPassiveMotionFunc(atualizarMouse);
    glutMotionFunc(movimentarMouse);

    glutSpecialFunc(specialKeys);
//ate aqui
    glutMainLoop();


    return 0;
}
