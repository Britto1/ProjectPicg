#ifndef ARQUIVO_H
#define ARQUIVO_H

#include <iostream>
#include <fstream>
#include <string>
#include <vector>

using namespace std;

class Arquivo{
	vector<int> cena;
	int ilha;
    int lagos;
    int terrestres_1;
    int terrestres_2;
    int aereos_1;
    int aereos_2;
    int plantas_1;
    int plantas_2;

public:

    Arquivo();

    void CarregarArquivo(string nomeArquivo);

    const vector<int> &getCena() const;

    const int getIlha() const;

    const int getLagos() const;

    const int getTerrestres_1() const;

    const int getTerrestres_2() const;

    const int getAereos_1() const;

    const int getAereos_2() const;

    const int getPlantas_1() const;

    const int getPlantas_2() const;

};

#endif // ARQUIVO_H
