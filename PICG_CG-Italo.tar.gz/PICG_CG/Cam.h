#ifndef CAM_H
#define CAM_H

#include <vector>
using namespace std;

class Cam{
	private:
		float posicaox;
		float posicaoy;
		float posicaoz;
		float rotacaox;
		float rotacaoy;
		float rotacaoz;
		float cameraVelocidade;

	public:
		Cam(vector<vector<char> > mundo);
		float getPosicaox() const;

		void setPosicaox(float obx);

		float getPosicaoy() const;

		void setPosicaoy(float oby);

		void setPosicaoz(float obz);

		float getPosicaoz() const;

		float getRotacaox() const;

		void setRotacaox(float alx);

		float getRotacaoy() const;

		void setRotacaoy(float aly);

		float getRotacaoz() const;

		void setRotacaoz(float alz);

		float getCameraVelocidade() const;

		void setCameraVelocidade(float cameraVelocidade);

        virtual ~Cam();
        Cam(const Cam& other);
        Cam& operator=(const Cam& other);
};



#endif // CAM_H
