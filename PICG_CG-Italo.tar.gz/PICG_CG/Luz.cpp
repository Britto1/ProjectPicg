#include "Luz.h"
#include <vector>
#include <GL/freeglut.h>

using namespace std;


Luz::Luz(int altura, vector<vector<char>> &mundo) {
    glEnable(GL_DEPTH_TEST);
    glShadeModel(GL_SMOOTH);
    iluminar(altura, mundo);
}

void Luz::iluminar(int altura, vector<vector<char>> &mundo) {

    GLfloat luz_pontual[] = {(float) mundo.size(), (float) altura, (float) mundo[0].size(), 1.0};
    GLfloat light1_diffuse[] = {1, 1, 1, 1};
    GLfloat light1_specular[] = {1.0, 1.0, 1.0, 1.0};
    GLfloat light1_ambient[] = {0.2, 0.2, 0.2, 1.0};

    glLightfv(GL_LIGHT1, GL_POSITION, luz_pontual); //determina onde sera colocada a fonte de luz
    glLightfv(GL_LIGHT1, GL_DIFFUSE, light1_diffuse); // determina a taxa de difusao da luz
    glLightfv(GL_LIGHT1, GL_SPECULAR, light1_specular); //intensidade especular da luz, sendo o atual, o padrão
    glLightfv(GL_LIGHT1, GL_AMBIENT, light1_ambient); //intensidade RGBA da luz no ambiente;
    glEnable(GL_LIGHT1);

}

void Luz::desenharLuz(int altura) {
    glPushAttrib(GL_LIGHTING_BIT);
    GLfloat mat_diffuse[] = {0.0, 1.0, 0.0, 1.0};
    GLfloat mat_emission[] = {1.0, 1.0, 1.0, 1.0};

    //atribui características ao material
    glMaterialfv(GL_FRONT, GL_DIFFUSE, mat_diffuse);
    glMaterialfv(GL_FRONT, GL_EMISSION, mat_emission);
    glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, mat_diffuse);

    glPushMatrix();
    glTranslatef(0, altura, 0);
    glEnable(GL_LIGHTING);
    glutSolidSphere(5, 50, 50);
    glDisable(GL_LIGHTING);

    glPopAttrib();
    glPopMatrix();
}

void Luz::propriedade() {
    GLfloat luz_pontual[] = {0.3, 0.5, 0.5, 1.0};
    glLightfv(GL_LIGHT1, GL_POSITION, luz_pontual);
}
